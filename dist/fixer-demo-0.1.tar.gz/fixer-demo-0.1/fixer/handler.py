def get_rates():
    print("Hello from get_rates")